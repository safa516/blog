(function($) {
    'use strict';
    
	$(document).on('ready', function() {
        $('.customize-collapsible' )
            .closest('.customize-control-kirki-custom[id*="_collapsible"]')
            .toggleClass('customize-control-collapsed');

        $('.customize-collapsible' )
            .closest('.customize-control-kirki-custom[id*="_collapsible"]')
            .nextUntil('.customize-control-kirki-custom[id*="_collapsible"]')
            .toggleClass('customize-control-hidden');

		$('.customize-collapsible').on('click', function() {
            $(this)
                .closest('.customize-control-kirki-custom[id*="_collapsible"]')
                .toggleClass('customize-control-collapsed');
            
            $(this)
                .closest('.customize-control-kirki-custom[id*="_collapsible"]')
                .nextUntil('.customize-control-kirki-custom[id*="_collapsible"]')
                .toggleClass('customize-control-hidden');
		});
    });
})(jQuery);