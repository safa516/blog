(function($, wp) {
    'use strict';
    
    function switchColorMode(el, value) {
        disabledColorMode(el);
    
        if (! value) {
            return;
        }
    
        $(el).addClass(`has-mode mode-${value}`);
    }
    
    function disabledColorMode(el) {
        $(el).removeClass('has-mode mode-dark mode-light');
    }

    wp.customize('body_mode', function(setting) {
        disabledColorMode('body');
        
        switchColorMode('body', setting.get());

        setting.bind(function(value) {
            switchColorMode('body', value);
        });
    });

    wp.customize('topbar_mode', function(setting) {
        disabledColorMode('.topbar');

        if (! wp.customize('topbar_customize_colors').get()) {
            return;
        }

        switchColorMode('.topbar', setting.get());

        setting.bind(function(value) {
            switchColorMode('.topbar', value);
        });
    });

    wp.customize('header_mode', function(setting) {
        disabledColorMode('.header');

        if (! wp.customize('header_customize_colors').get()) {
            return;
        }

        switchColorMode('.header', setting.get());

        setting.bind(function(value) {
            switchColorMode('.header', value);
        });
    });

    wp.customize('header_mobile_mode', function(setting) {
        disabledColorMode('.header-mobile');

        if (! wp.customize('header_mobile_customize_colors').get()) {
            return;
        }

        switchColorMode('.header-mobile', setting.get());

        setting.bind(function(value) {
            switchColorMode('.header-mobile', value);
        });
    });

    wp.customize('drawer_mode', function(setting) {
        disabledColorMode('.drawer-inner');

        if (! wp.customize('drawer_customize_colors').get()) {
            return;
        }

        switchColorMode('.drawer-inner', setting.get());

        setting.bind(function(value) {
            switchColorMode('.drawer-inner', value);
        });
    });

    wp.customize('footer_mode', function(setting) {
        disabledColorMode('.site-footer');

        if (! wp.customize('footer_customize_colors').get()) {
            return;
        }

        switchColorMode('.site-footer', setting.get());

        setting.bind(function(value) {
            switchColorMode('.site-footer', value);
        });
    });

    wp.customize('dropdown_mode', function(setting) {
        disabledColorMode('.dropdown-menu');

        switchColorMode('.dropdown-menu', setting.get());

        setting.bind(function(value) {
            switchColorMode('.dropdown-menu', value);
        });
    });
})(jQuery, wp);